let elements = [
  "title",
  "subtitle",
  "header",
  "heading1",
  "heading2",
  "content1",
  "content2",
  "content3",
  "content4",
  "heading2",
  "content5",
  "li1",
  "li2",
  "li3",
  "li4",
  "li5",
  "content6",
  "content7",
  "content7a",
  "content7b",
  "heading3",
  "content8",
  "li6",
  "li6a",
  "li7",
  "li8",
  "li9",
  "li10",
  "li11",
  "li12",
  "li13",
  "li14",
  "content9",
  "content9a",
  "h4",
  "li15",
  "li16",
  "li17",
  "li18",
  "h5",
  "content10",
  "content11",
  "content12",
  "content13",
  "heading5",
  "heading6",
  "content14",
  "content15",
  "content16",
  "content17",
  "li19",
  "li20",
  "li21",
  "li22",
  "li23",
  "h7",
  "content18",
  "content18a",
  "content19",
  "content20",
  "link",
  "link1",
];

let lang = localStorage.getItem("lang") || "nl";

// Get the language from the URL if present
const urlParams = new URLSearchParams(window.location.search);
const urlLang = urlParams.get("lang");

if (urlLang && (urlLang === "en" || urlLang === "nl")) {
  lang = urlLang;
} else {
  //replaceURL();
}

// function replaceURL() {
//   urlParams.set("lang", lang);
//   window.history.replaceState(
//     {},
//     "",
//     `${window.location.pathname}?${urlParams}`
//   );
//   document.getElementById("langName").textContent = lang.toUpperCase();
// }

// Add an event listener to each language link inside the dropdown menu
document.querySelectorAll(".dropdown-item__navbar").forEach((link) => {
  link.addEventListener("click", function (e) {
    e.preventDefault();
    lang = this.dataset.lang;
    console.log("lang", lang);
    localStorage.setItem("lang", this.dataset.lang);

    document.getElementById("langName").textContent =
      this.dataset.lang.toUpperCase();

    urlParams.set("lang", lang);
    window.history.replaceState(
      {},
      "",
      `${window.location.pathname}?${urlParams}`
    );
    loadLanguage(lang);
  });
});

function loadLanguage(lang) {
  fetch(`./languages/${lang}.json`)
    .then((response) => response.json())
    .then((data) => {
      elements.forEach((element) => {
        const elementList = document.getElementsByClassName(element);
        Array.from(elementList).forEach((el) => {
          if (
            el?.tagName.toLowerCase() === "input" &&
            el?.getAttribute("placeholder")
          ) {
            el.setAttribute("placeholder", data[element]);
          } else if (el?.tagName.toLowerCase() === "textarea") {
            el.placeholder = data[element];
          } else {
            el.innerHTML = data[element];
          }
        });
        // document.getElementById(
        //   `${element}`
        // ).innerHTML = `${data[element]}`;
      });
    });
}

// Load the default language on page load
loadLanguage(lang);

//Load the language stored in localStorage or the default language on page load
document.addEventListener("DOMContentLoaded", function () {
  console.log("lang", lang);
  loadLanguage(lang);

  let langLS = localStorage.getItem("lang");
  if (langLS) {
    document.getElementById("langName").textContent = langLS.toUpperCase();
  }
});
